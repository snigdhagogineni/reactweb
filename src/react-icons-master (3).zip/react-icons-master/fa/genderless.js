
import React from 'react'
import Icon from 'react-icon-base'

const FaGenderless = props => (
    <Icon viewBox="0 0 40 40" {...props}>
        <g><path d="m29.9 21.4q0-4.1-3-7t-7-3-7.1 3-2.9 7 2.9 7.1 7.1 2.9 7-2.9 3-7.1z m2.8 0q0 2.6-1 5t-2.7 4.1-4.2 2.8-4.9 1-5-1-4.1-2.8-2.8-4.1-1-5 1-5 2.8-4.1 4.1-2.7 5-1 4.9 1 4.2 2.7 2.7 4.1 1 5z"/></g>
    </Icon>
)

export default FaGenderless
