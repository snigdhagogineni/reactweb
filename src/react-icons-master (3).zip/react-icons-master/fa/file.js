
import React from 'react'
import Icon from 'react-icon-base'

const FaFile = props => (
    <Icon viewBox="0 0 40 40" {...props}>
        <g><path d="m25.9 11.4v-10.5q0.4 0.3 0.8 0.6l9.1 9.1q0.3 0.3 0.6 0.8h-10.5z m-2.9 0.7q0 0.9 0.6 1.6t1.5 0.6h12.2v23.6q0 0.9-0.6 1.5t-1.6 0.6h-30q-0.8 0-1.5-0.6t-0.6-1.5v-35.8q0-0.8 0.6-1.5t1.5-0.6h17.9v12.1z"/></g>
    </Icon>
)

export default FaFile
