import IconBase from 'react-icon-base';

export default IconBase;
